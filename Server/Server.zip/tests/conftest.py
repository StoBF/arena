import pytest
import pytest_asyncio
import httpx
from httpx import AsyncClient as _AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_session, create_db_and_tables
from app.database.models.user import User
from app.database.models.craft import CraftedItem
from app.main import app
from app.utils.jwt import create_access_token

# Monkey-patch httpx.AsyncClient to accept 'app' for ASGITransport
class AsyncClient(_AsyncClient):
    def __init__(self, *args, app=None, transport=None, **kwargs):
        if app is not None:
            transport = ASGITransport(app=app)
        super().__init__(*args, transport=transport, **kwargs)

httpx.AsyncClient = AsyncClient

@pytest_asyncio.fixture(scope="session", autouse=True)
async def init_db():
    # Create database tables before any tests run
    await create_db_and_tables()

@pytest_asyncio.fixture
async def db() -> AsyncSession:
    # Provide a fresh AsyncSession for each test
    async for session in get_session():
        yield session
        await session.rollback()

@pytest_asyncio.fixture
async def test_user(db: AsyncSession):
    user = User(username="testuser", email="test@example.com")
    db.add(user)
    await db.flush()
    return user

@pytest_asyncio.fixture
async def test_user_token(test_user: User):
    # Issue JWT for test user
    return create_access_token({"sub": str(test_user.id), "role": test_user.role})

@pytest_asyncio.fixture
async def other_user_crafted_item_id(db: AsyncSession):
    # Create a second user and a crafted item for them
    other = User(username="otheruser", email="other@example.com")
    db.add(other)
    await db.flush()
    crafted = CraftedItem(
        user_id=other.id,
        result_item_id=None,
        item_type="material",
        grade=1,
        recipe_id=1,
    )
    db.add(crafted)
    await db.commit()
    return crafted.id

@pytest_asyncio.fixture
async def test_client():
    # HTTP client bound to our FastAPI app
    async with AsyncClient(app=app, base_url="http://testserver") as client:
        yield client
