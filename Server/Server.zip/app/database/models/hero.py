from sqlalchemy import Column, Integer, String, ForeignKey, UniqueConstraint, Boolean, DateTime
from sqlalchemy.orm import relationship
from app.database.base import Base
from datetime import datetime

class Hero(Base):
    __tablename__ = "heroes"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    generation = Column(Integer, nullable=False)
    nickname = Column(String(100), nullable=False)
    strength = Column(Integer, nullable=False)
    agility = Column(Integer, nullable=False)
    intelligence = Column(Integer, nullable=True, default=0)
    endurance = Column(Integer, nullable=False)
    speed = Column(Integer, nullable=False)
    health = Column(Integer, nullable=False)
    defense = Column(Integer, nullable=False)
    luck = Column(Integer, nullable=False)
    field_of_view = Column(Integer, nullable=False)
    gold = Column(Integer, default=0)
    level = Column(Integer, nullable=False, default=1)
    experience = Column(Integer, nullable=False, default=0)
    is_training = Column(Boolean, default=False)
    training_end_time = Column(DateTime, nullable=True)
    locale = Column(String(5), nullable=False, default="en")
    owner_id = Column(Integer, ForeignKey("users.id"))
    owner = relationship("User", back_populates="heroes")
    perks = relationship("HeroPerk", back_populates="hero", cascade="all, delete-orphan")
    is_deleted = Column(Boolean, default=False)
    deleted_at = Column(DateTime, nullable=True)
    equipment_items = relationship("Equipment", back_populates="hero", cascade="all, delete-orphan")
    is_dead = Column(Boolean, default=False)
    dead_until = Column(DateTime, nullable=True)
    is_on_auction = Column(Boolean, default=False)

class HeroPerk(Base):
    __tablename__ = "hero_perks"
    id = Column(Integer, primary_key=True)
    hero_id = Column(Integer, ForeignKey("heroes.id", ondelete="CASCADE"))
    perk_id = Column(Integer, ForeignKey("perks.id"), nullable=False)
    perk_level = Column(Integer, nullable=False)
    hero = relationship("Hero", back_populates="perks")
    perk = relationship("Perk")
    __table_args__ = (UniqueConstraint('hero_id', 'perk_id', name='_hero_perk_uc'),) 