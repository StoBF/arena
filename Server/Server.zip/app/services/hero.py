# app/services/hero.py

from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import func
from datetime import datetime, timedelta
from fastapi import HTTPException
from app.database.models.hero import Hero, HeroPerk
from app.database.models.perk import Perk
from app.database.models.models import Auction
from app.services.base_service import BaseService
from app.services.hero_generation import generate_hero
from app.schemas.hero import HeroCreate, HeroOut, HeroRead, HeroGenerateRequest, PerkOut
from app.auth import get_current_user
from app.database.session import get_session, AsyncSessionLocal
from app.core.hero_config import MAX_HEROES
import json
import asyncio
from app.services.auction import AuctionService
from app.services.message import MessageService
from fastapi import Depends
from sqlalchemy.orm import joinedload

class HeroService(BaseService):
    async def create_hero(self, name: str, owner_id: int):
        res = await self.session.execute(
            select(func.count()).select_from(Hero).where(Hero.owner_id == owner_id, Hero.is_deleted == False)
        )
        (count,) = res.one()
        if count >= MAX_HEROES:
            raise HTTPException(status_code=400, detail="Maximum heroes limit reached")
        hero = Hero(name=name, owner_id=owner_id, is_deleted=False)
        self.session.add(hero)
        await self.commit_or_rollback()
        await self.session.refresh(hero)
        return hero

    async def get_hero(self, hero_id: int, only_active: bool = True):
        query = select(Hero).where(Hero.id == hero_id)
        if only_active:
            query = query.where(Hero.is_deleted == False)
        result = await self.session.execute(query)
        return result.scalars().first()

    async def list_heroes(self, user_id: int = None):
        query = select(Hero).options(joinedload(Hero.perks), joinedload(Hero.equipment_items)).where(Hero.is_deleted == False)
        if user_id is not None:
            query = query.where(Hero.owner_id == user_id)
        result = await self.session.execute(query)
        return result.scalars().all()

    async def update_hero(self, hero_id: int, name: str, user_id: int):
        hero = await self.get_hero(hero_id)
        if not hero or hero.owner_id != user_id:
            raise HTTPException(status_code=404, detail="Hero not found")
        hero.name = name
        await self.commit_or_rollback()
        await self.session.refresh(hero)
        return hero

    async def delete_hero(self, hero_id: int, user_id: int):
        hero = await self.get_hero(hero_id, only_active=True)
        if not hero or hero.owner_id != user_id:
            raise HTTPException(status_code=404, detail="Hero not found or not yours")
        hero.is_deleted = True
        hero.deleted_at = datetime.utcnow()
        await self.commit_or_rollback()
        return hero

    async def restore_hero(self, hero_id: int, user_id: int):
        hero = await self.get_hero(hero_id, only_active=False)
        if not hero or not hero.is_deleted or hero.owner_id != user_id:
            raise HTTPException(status_code=404, detail="Hero not found or not yours")
        cutoff = datetime.utcnow() - timedelta(days=7)
        if not hero.deleted_at or hero.deleted_at < cutoff:
            raise HTTPException(status_code=404, detail="Restore period expired")
        hero.is_deleted = False
        hero.deleted_at = None
        await self.commit_or_rollback()
        return hero

    async def generate_and_store(self, owner_id: int, req: HeroGenerateRequest):
        # Виклик функції генерації та отримання даних героя
        hero_data = await generate_hero(self.session, owner_id, req.generation, req.currency, req.locale)
        new_hero = Hero(
            name=hero_data.name,
            owner_id=owner_id,
            generation=hero_data.generation,
            nickname=hero_data.nickname,
            strength=hero_data.strength,
            agility=hero_data.agility,
            intelligence=hero_data.intelligence,
            endurance=hero_data.endurance,
            locale=hero_data.locale,
            is_deleted=False
        )
        self.session.add(new_hero)
        await self.session.commit()
        await self.session.refresh(new_hero)
        return new_hero

    async def send_offline_messages(self, user_id: int, websocket: str):
        from app.services.notification import NotificationService
        await NotificationService.send_offline_messages(user_id, websocket)

    async def add_experience(self, hero_id: int, amount: int):
        hero = await self.get_hero(hero_id)
        if not hero:
            raise HTTPException(status_code=404, detail="Hero not found")
        hero.experience += amount
        # Формула для наступного рівня: exp = 100 * (level ** 1.5)
        leveled_up = False
        while hero.experience >= int(100 * (hero.level ** 1.5)):
            hero.experience -= int(100 * (hero.level ** 1.5))
            hero.level += 1
            leveled_up = True
        await self.commit_or_rollback()
        await self.session.refresh(hero)
        return hero, leveled_up

    async def get_total_stats(self, hero_id: int):
        hero = await self.get_hero(hero_id)
        if not hero:
            raise HTTPException(status_code=404, detail="Hero not found")
        # Базові атрибути
        stats = {
            "strength": hero.strength,
            "agility": hero.agility,
            "intelligence": hero.intelligence,
            "endurance": hero.endurance,
            "speed": hero.speed,
            "health": hero.health,
            "defense": hero.defense,
            "luck": hero.luck,
            "field_of_view": hero.field_of_view,
        }
        # Додаємо бонуси від екіпіровки
        for eq in hero.equipment_items:
            item = eq.item
            stats["strength"] += getattr(item, "bonus_strength", 0)
            stats["agility"] += getattr(item, "bonus_agility", 0)
            stats["intelligence"] += getattr(item, "bonus_intelligence", 0)
            # Можна додати бонуси для інших атрибутів, якщо вони є у Item
        return stats

    def get_nickname(self, hero, perks=None, locale="en"):
        from app.core.hero_config import NICKNAME_MAP
        attrs = {
            "strength": hero.strength,
            "agility": hero.agility,
            "intelligence": hero.intelligence,
            "endurance": hero.endurance,
            "speed": hero.speed,
            "health": hero.health,
            "defense": hero.defense,
            "luck": hero.luck,
            "field_of_view": hero.field_of_view,
        }
        max_attr = max(attrs.items(), key=lambda x: x[1])
        trait_key = max_attr[0]
        if perks:
            max_perk = max(perks, key=lambda x: x[1]) if perks else (None, 0)
            if max_perk[1] >= 100 or (max_perk[1] > max_attr[1] + 10):
                trait_key = max_perk[0]
        return NICKNAME_MAP.get(locale, NICKNAME_MAP["en"]).get(trait_key, "the Hero")

    async def start_training(self, hero_id: int, duration_minutes: int = 60):
        hero = await self.get_hero(hero_id)
        if not hero:
            raise HTTPException(status_code=404, detail="Hero not found")
        if hero.is_training:
            raise HTTPException(status_code=400, detail="Hero is already training")
        hero.is_training = True
        hero.training_end_time = datetime.utcnow() + timedelta(minutes=duration_minutes)
        await self.commit_or_rollback()
        await self.session.refresh(hero)
        return hero

    async def complete_training(self, hero_id: int, xp_reward: int = 50):
        hero = await self.get_hero(hero_id)
        if not hero:
            raise HTTPException(status_code=404, detail="Hero not found")
        if not hero.is_training:
            raise HTTPException(status_code=400, detail="Hero is not in training")
        if not hero.training_end_time or hero.training_end_time > datetime.utcnow():
            raise HTTPException(status_code=400, detail="Training not finished yet")
        hero.is_training = False
        hero.training_end_time = None
        await self.add_experience(hero.id, xp_reward)
        await self.commit_or_rollback()
        await self.session.refresh(hero)
        return hero

    async def get_hero_with_perks(self, hero_id: int) -> HeroRead:
        hero = await self.session.get(Hero, hero_id)
        if not hero:
            raise HTTPException(status_code=404, detail="Hero not found")
        # Підвантажити перки з Perk
        perks = []
        for hp in hero.perks:
            perk = await self.session.get(Perk, hp.perk_id)
            if perk:
                perks.append(PerkOut(
                    id=perk.id,
                    name=perk.name,
                    description=perk.description,
                    effect_type=perk.effect_type,
                    max_level=perk.max_level,
                    modifiers=perk.modifiers or {},
                    affected=perk.affected or [],
                    perk_level=hp.perk_level
                ))
        hero_dict = HeroRead.model_validate(hero, from_attributes=True).model_dump()
        hero_dict["perks"] = perks
        return HeroRead(**hero_dict)

    async def upgrade_perk(self, hero_id: int, perk_id: int, user_id: int, max_level: int = 100):
        hero = await self.get_hero(hero_id)
        if not hero or hero.owner_id != user_id:
            raise HTTPException(status_code=404, detail="Hero not found or not yours")
        # Знайти перк героя
        perk = None
        for p in hero.perks:
            if p.perk_id == perk_id:
                perk = p
                break
        if not perk:
            raise HTTPException(status_code=404, detail="Perk not found for this hero")
        if perk.perk_level >= max_level:
            raise HTTPException(status_code=400, detail=f"Perk already at max level {max_level}")
        perk.perk_level += 1
        await self.commit_or_rollback()
        await self.session.refresh(perk)
        return perk
