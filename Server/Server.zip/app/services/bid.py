from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.models.models import Bid, Auction, AuctionLot, AutoBid
from app.database.models.user import User
from app.database.models.hero import Hero
from sqlalchemy import and_
from fastapi import HTTPException
from app.services.base_service import BaseService
from datetime import datetime

class BidService(BaseService):
    async def _create_bid(self, lot_id: int, bidder_id: int, bid_amount: int):
        """
        Приватний метод для створення ставки на лот (не використовувати напряму, тільки як хелпер).
        """
        async with self.session.begin():
            lot_result = await self.session.execute(select(AuctionLot).where(AuctionLot.id == lot_id))
            lot = lot_result.scalars().first()
            if not lot:
                raise HTTPException(404, "Auction lot not found")
            hero = await self.session.get(Hero, lot.hero_id, with_for_update=True)
            if not hero:
                raise HTTPException(404, "Hero not found")
            if hero.owner_id == bidder_id:
                raise HTTPException(403, "Cannot bid on your own lot")
            user_result = await self.session.execute(select(User).where(User.id == bidder_id))
            user = user_result.scalars().first()
            if not user:
                raise HTTPException(404, "User not found")
            if user.balance - user.reserved < bid_amount:
                raise HTTPException(400, "Insufficient funds")
            prev_bid_result = await self.session.execute(
                select(Bid).where(Bid.lot_id == lot_id).order_by(Bid.bid_amount.desc())
            )
            prev_bid = prev_bid_result.scalars().first()
            if prev_bid and prev_bid.bidder_id != bidder_id:
                prev_user_result = await self.session.execute(select(User).where(User.id == prev_bid.bidder_id))
                prev_user = prev_user_result.scalars().first()
                if prev_user:
                    prev_user.reserved -= prev_bid.bid_amount
            user.reserved += bid_amount
            bid = Bid(lot_id=lot_id, bidder_id=bidder_id, bid_amount=bid_amount)
            self.session.add(bid)
            await self.session.flush()
            await self.session.refresh(bid)
            return bid

    async def get_bid(self, bid_id: int):
        """Отримати ставку за id."""
        result = await self.session.execute(select(Bid).where(Bid.id == bid_id))
        return result.scalars().first()

    async def list_bids(self):
        """Список всіх ставок."""
        result = await self.session.execute(select(Bid))
        return result.scalars().all()

    async def delete_bid(self, bid_id: int):
        """Видалити ставку."""
        bid = await self.get_bid(bid_id)
        if bid:
            await self.session.delete(bid)
            await self.commit_or_rollback()
        return bid

    async def place_bid(self, bidder_id: int, auction_id: int, amount: int):
        """Зробити ставку на аукціон (Auction). Сума — int."""
        auction = await self.session.get(Auction, auction_id)
        if auction is None or auction.status != "active" or auction.end_time < datetime.utcnow():
            raise HTTPException(400, "Auction is not active")
        if auction.seller_id == bidder_id:
            raise HTTPException(400, "Seller cannot bid on own auction")
        if amount <= auction.current_price:
            raise HTTPException(400, "Bid must be higher than current price")
        user = await self.session.get(User, bidder_id)
        if not user or user.balance - user.reserved < amount:
            raise HTTPException(400, "Insufficient funds")
        # Повернення резерву попередньому лідеру
        prev_bid = (await self.session.execute(
            select(Bid).where(Bid.auction_id == auction_id).order_by(Bid.amount.desc())
        )).scalars().first()
        if prev_bid and prev_bid.bidder_id != bidder_id:
            prev_user = await self.session.get(User, prev_bid.bidder_id)
            if prev_user:
                prev_user.reserved -= prev_bid.amount
        # Резервування коштів нового лідера
        user.reserved += amount
        bid = Bid(auction_id=auction_id, bidder_id=bidder_id, amount=amount, created_at=datetime.utcnow())
        self.session.add(bid)
        auction.current_price = amount
        auction.winner_id = bidder_id
        await self.session.commit()
        await self.session.refresh(bid)
        return bid

    async def place_lot_bid(self, bidder_id: int, lot_id: int, amount: int):
        """Зробити ставку на лот (AuctionLot). Сума — int."""
        lot = await self.session.get(AuctionLot, lot_id)
        if lot is None or not lot.is_active or lot.end_time < datetime.utcnow():
            raise HTTPException(400, "Auction lot is not active")
        if lot.seller_id == bidder_id:
            raise HTTPException(400, "Seller cannot bid on own lot")
        if amount <= lot.current_price:
            raise HTTPException(400, "Bid must be higher than current price")
        user = await self.session.get(User, bidder_id)
        if not user or user.balance - user.reserved < amount:
            raise HTTPException(400, "Insufficient funds")
        # Повернення резерву попередньому лідеру
        prev_bid = (await self.session.execute(
            select(Bid).where(Bid.lot_id == lot_id).order_by(Bid.amount.desc())
        )).scalars().first()
        if prev_bid and prev_bid.bidder_id != bidder_id:
            prev_user = await self.session.get(User, prev_bid.bidder_id)
            if prev_user:
                prev_user.reserved -= prev_bid.amount
        # Резервування коштів нового лідера
        user.reserved += amount
        bid = Bid(lot_id=lot_id, bidder_id=bidder_id, amount=amount, created_at=datetime.utcnow())
        self.session.add(bid)
        lot.current_price = amount
        lot.winner_id = bidder_id
        await self.session.commit()
        await self.session.refresh(bid)
        return bid

    async def set_auto_bid(self, user_id: int, auction_id: int = None, lot_id: int = None, max_amount: int = 0):
        """Встановити або оновити автоставку (AutoBid). max_amount — int."""
        user = await self.session.get(User, user_id)
        if not user or user.balance - user.reserved < max_amount:
            raise HTTPException(400, "Insufficient funds for autobid reserve")
        autobid = None
        if auction_id:
            autobid = (await self.session.execute(
                select(AutoBid).where(AutoBid.auction_id == auction_id, AutoBid.user_id == user_id)
            )).scalars().first()
        elif lot_id:
            autobid = (await self.session.execute(
                select(AutoBid).where(AutoBid.lot_id == lot_id, AutoBid.user_id == user_id)
            )).scalars().first()
        if autobid:
            autobid.max_amount = max_amount
        else:
            autobid = AutoBid(auction_id=auction_id, lot_id=lot_id, user_id=user_id, max_amount=max_amount)
            self.session.add(autobid)
        user.reserved += max_amount
        await self.session.commit()
        await self.session.refresh(autobid)
        return autobid