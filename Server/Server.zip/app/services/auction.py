from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import and_, or_
from datetime import datetime, timedelta
from fastapi import HTTPException
from app.database.models.models import Auction, Bid, Stash, AuctionLot, AutoBid
from app.database.models.hero import Hero
from app.database.models.user import User
from app.services.base_service import BaseService
from app.core.redis_cache import redis_cache
from sqlalchemy.orm import joinedload, selectinload

class AuctionService(BaseService):
    async def create_auction(self, seller_id: int, item_id: int, start_price: int, duration: int, quantity: int = 1):
        # Перевірка наявності предмета у складі користувача
        stash = await self.session.execute(
            select(Stash).where(Stash.user_id == seller_id, Stash.item_id == item_id, Stash.quantity >= quantity)
        )
        stash_entry = stash.scalars().first()
        if not stash_entry or stash_entry.quantity < quantity:
            raise HTTPException(403, "Seller does not own enough of this item")
        # Зменшуємо кількість або видаляємо предмет зі складу
        if stash_entry.quantity > quantity:
            stash_entry.quantity -= quantity
        else:
            await self.session.delete(stash_entry)
        end_time = datetime.utcnow() + timedelta(hours=duration)
        auction = Auction(
            item_id=item_id,
            seller_id=seller_id,
            start_price=start_price,
            current_price=start_price,
            end_time=end_time,
            status="active",
            created_at=datetime.utcnow(),
            quantity=quantity
        )
        self.session.add(auction)
        await self.session.commit()
        await self.session.refresh(auction)
        await redis_cache.delete("auctions:active")
        return auction

    async def get_auction(self, auction_id: int):
        result = await self.session.execute(select(Auction).where(Auction.id == auction_id))
        return result.scalars().first()

    async def list_auctions(self, active_only: bool = False):
        query = select(Auction).options(joinedload(Auction.bids))
        if active_only:
            query = query.where(and_(Auction.status == "active", Auction.end_time > datetime.utcnow()))
        result = await self.session.execute(query)
        return result.scalars().all()

    async def cancel_auction(self, auction_id: int, seller_id: int):
        auction = await self.get_auction(auction_id)
        if not auction or auction.seller_id != seller_id:
            raise HTTPException(403, "Not allowed to cancel this auction")
        if auction.status != "active" or auction.end_time < datetime.utcnow():
            raise HTTPException(400, "Auction is not active or already ended")
        # Перевірка наявності ставок
        if auction.current_price != auction.start_price:
            raise HTTPException(400, "Cannot cancel - bids already placed")
        auction.status = "canceled"
        # Повернення предмета продавцю
        stash = await self.session.execute(
            select(Stash).where(Stash.user_id == seller_id, Stash.item_id == auction.item_id)
        )
        stash_entry = stash.scalars().first()
        if stash_entry:
            stash_entry.quantity += auction.quantity
        else:
            self.session.add(Stash(user_id=seller_id, item_id=auction.item_id, quantity=auction.quantity))
        await self.session.commit()
        await redis_cache.delete("auctions:active")
        return auction

    async def close_auction(self, auction_id: int):
        auction = await self.get_auction(auction_id)
        if not auction or auction.status != "active":
            raise HTTPException(404, "Auction not found or not active")
        auction.status = "closed"
        # Знаходимо максимальну ставку
        result = await self.session.execute(
            select(Bid).where(Bid.auction_id == auction_id).order_by(Bid.amount.desc()).limit(1)
        )
        highest_bid = result.scalars().first()
        if highest_bid:
            auction.winner_id = highest_bid.bidder_id
            # Передача предмета переможцю
            stash = await self.session.execute(
                select(Stash).where(Stash.user_id == highest_bid.bidder_id, Stash.item_id == auction.item_id)
            )
            stash_entry = stash.scalars().first()
            if stash_entry:
                stash_entry.quantity += auction.quantity
            else:
                self.session.add(Stash(user_id=highest_bid.bidder_id, item_id=auction.item_id, quantity=auction.quantity))
            # Перерахунок валюти
            winner = await self.session.get(User, highest_bid.bidder_id)
            seller = await self.session.get(User, auction.seller_id)
            if winner and seller:
                winner.reserved -= highest_bid.amount
                seller.balance += highest_bid.amount
        else:
            # Ставок не було – повернути предмет продавцю
            stash = await self.session.execute(
                select(Stash).where(Stash.user_id == auction.seller_id, Stash.item_id == auction.item_id)
            )
            stash_entry = stash.scalars().first()
            if stash_entry:
                stash_entry.quantity += auction.quantity
            else:
                self.session.add(Stash(user_id=auction.seller_id, item_id=auction.item_id, quantity=auction.quantity))
        await self.session.commit()
        await redis_cache.delete("auctions:active")
        return auction

    async def create_auction_lot(self, hero_id: int, seller_id: int, starting_price: int, duration: int, buyout_price: int = None):
        # Forbid more than one active lot per hero
        existing = await self.session.execute(select(AuctionLot).where(AuctionLot.hero_id == hero_id, AuctionLot.is_active == 1))
        if existing.scalars().first():
            raise HTTPException(400, "Active lot for this hero already exists")
        # Load hero with equipment_items to avoid lazy-loading outside greenlet
        result = await self.session.execute(
            select(Hero).options(selectinload(Hero.equipment_items)).where(Hero.id == hero_id)
        )
        hero = result.scalars().first()
        if not hero or hero.owner_id != seller_id:
            raise HTTPException(403, "You do not own this hero")
        if hero.is_dead or hero.is_training:
            raise HTTPException(400, "Hero is dead or in training")
        if hero.is_on_auction:
            raise HTTPException(400, "Hero is already on auction")
        if hero.equipment_items:
            raise HTTPException(400, "Remove all equipment from hero before auction")
        end_time = datetime.utcnow() + timedelta(hours=duration)
        lot = AuctionLot(hero_id=hero_id, seller_id=seller_id, starting_price=starting_price, current_price=starting_price, buyout_price=buyout_price, end_time=end_time, is_active=1, created_at=datetime.utcnow())
        hero.is_on_auction = True
        self.session.add(lot)
        await self.commit_or_rollback()
        await self.session.refresh(lot)
        await redis_cache.delete("auctions:active")
        return lot

    async def get_auction_lot(self, lot_id: int):
        result = await self.session.execute(select(AuctionLot).where(AuctionLot.id == lot_id))
        return result.scalars().first()

    async def list_auction_lots(self):
        result = await self.session.execute(
            select(AuctionLot).options(joinedload(AuctionLot.bids)).where(AuctionLot.is_active == 1)
        )
        return result.scalars().all()

    async def delete_auction_lot(self, lot_id: int, seller_id: int):
        lot = await self.get_auction_lot(lot_id)
        if not lot or lot.seller_id != seller_id:
            raise HTTPException(403, "Not allowed to delete this lot")
        if lot.current_price != lot.starting_price:
            raise HTTPException(400, "Cannot delete lot with bids")
        hero = await self.session.get(Hero, lot.hero_id)
        hero.is_on_auction = False
        await self.session.delete(lot)
        await self.commit_or_rollback()
        await redis_cache.delete("auctions:active")
        return lot

    async def close_auction_lot(self, lot_id: int):
        lot = await self.get_auction_lot(lot_id)
        if not lot or not lot.is_active:
            raise HTTPException(404, "Auction lot not found or already closed")
        # Знаходимо максимальну ставку
        result = await self.session.execute(
            select(Bid).where(Bid.lot_id == lot_id).order_by(Bid.amount.desc()).limit(1)
        )
        highest_bid = result.scalars().first()
        hero = await self.session.get(Hero, lot.hero_id)
        if highest_bid:
            lot.winner_id = highest_bid.bidder_id
            # Передача героя переможцю
            winner = await self.session.get(User, highest_bid.bidder_id)
            seller = await self.session.get(User, lot.seller_id)
            if winner and seller:
                winner.reserved -= highest_bid.amount
                seller.balance += highest_bid.amount
            hero.owner_id = highest_bid.bidder_id
            hero.is_on_auction = False
        else:
            # Ставок не було – повернути героя продавцю
            hero.is_on_auction = False
        lot.is_active = 0
        await self.commit_or_rollback()
        await redis_cache.delete("auctions:active")
        return lot