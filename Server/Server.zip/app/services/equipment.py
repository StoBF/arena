from sqlalchemy.future import select
from fastapi import HTTPException
from app.database.models.models import Equipment, Stash, Item, SlotType
from app.services.base_service import BaseService

class EquipmentService(BaseService):
    async def equip_item(self, hero_id: int, user_id: int, item_id: int, slot: SlotType):
        # Перевірка наявності предмета у складі користувача
        stash_entry = (await self.session.execute(
            select(Stash).where(Stash.user_id == user_id, Stash.item_id == item_id)
        )).scalars().first()
        if not stash_entry or stash_entry.quantity < 1:
            raise HTTPException(400, "Item not in user's stash")
        item = (await self.session.execute(
            select(Item).where(Item.id == item_id)
        )).scalars().first()
        if not item or item.slot_type != slot:
            raise HTTPException(400, "Item cannot be equipped to this slot")
        # Автозаміна, якщо слот зайнятий
        old_eq = (await self.session.execute(
            select(Equipment).where(Equipment.hero_id == hero_id, Equipment.slot == slot)
        )).scalars().first()
        if old_eq:
            old_item_id = old_eq.item_id
            self.session.delete(old_eq)
            old_stash = (await self.session.execute(
                select(Stash).where(Stash.user_id == user_id, Stash.item_id == old_item_id)
            )).scalars().first()
            if old_stash:
                old_stash.quantity += 1
            else:
                self.session.add(Stash(user_id=user_id, item_id=old_item_id, quantity=1))
        # Зменшити кількість або видалити зі складу новий предмет
        if stash_entry.quantity > 1:
            stash_entry.quantity -= 1
        else:
            await self.session.delete(stash_entry)
        # Додати новий запис екіпіровки
        equipment = Equipment(hero_id=hero_id, item_id=item_id, slot=slot)
        self.session.add(equipment)
        await self.commit_or_rollback()
        await self.session.refresh(equipment)
        return equipment

    async def unequip_item(self, hero_id: int, user_id: int, slot: SlotType):
        equipment = (await self.session.execute(
            select(Equipment).where(Equipment.hero_id == hero_id, Equipment.slot == slot)
        )).scalars().first()
        if not equipment:
            raise HTTPException(404, "Nothing to unequip in this slot")
        item_id = equipment.item_id
        self.session.delete(equipment)
        stash_entry = (await self.session.execute(
            select(Stash).where(Stash.user_id == user_id, Stash.item_id == item_id)
        )).scalars().first()
        if stash_entry:
            stash_entry.quantity += 1
        else:
            self.session.add(Stash(user_id=user_id, item_id=item_id, quantity=1))
        await self.commit_or_rollback()
        return True

    async def get_equipment(self, hero_id: int):
        result = await self.session.execute(
            select(Equipment).where(Equipment.hero_id == hero_id)
        )
        return result.scalars().all()

    async def list_equipment(self, hero_ids: list):
        result = await self.session.execute(
            select(Equipment).where(Equipment.hero_id.in_(hero_ids))
        )
        return result.scalars().all() 