from sqlalchemy.future import select
from app.database.session import AsyncSessionLocal
import json
from app.services.notification import NotificationService

class MessageService:
    pass 