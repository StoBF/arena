from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.models.user import User
from passlib.context import CryptContext
from app.utils.jwt import create_access_token, create_refresh_token, decode_refresh_token
from app.services.base_service import BaseService

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class AuthService(BaseService):
    async def get_user_by_email_or_username(self, login: str):
        query = select(User).where((User.email == login) | (User.username == login))
        result = await self.session.execute(query)
        return result.scalars().first()

    async def create_user(self, email: str, username: str | None, password: str | None, is_google: bool = False):
        hashed_password = pwd_context.hash(password) if password else None
        new_user = User(
            email=email,
            username=username,
            hashed_password=hashed_password,
            is_google_account=is_google
        )
        self.session.add(new_user)
        await self.commit_or_rollback()
        await self.session.refresh(new_user)
        return new_user

    async def authenticate_user(self, login: str, password: str):
        user = await self.get_user_by_email_or_username(login)
        if user and user.hashed_password and pwd_context.verify(password, user.hashed_password):
            return user
        return None

    def generate_tokens(self, user: User):
        access = create_access_token({"sub": str(user.id), "role": user.role})
        refresh = create_refresh_token({"sub": str(user.id), "role": user.role})
        return {"access_token": access, "refresh_token": refresh, "token_type": "bearer"}

    def refresh_access_token(self, refresh_token: str):
        payload = decode_refresh_token(refresh_token)
        if not payload or "sub" not in payload or "role" not in payload:
            return None
        user_id = payload["sub"]
        role = payload["role"]
        return create_access_token({"sub": user_id, "role": role})

# Module-level wrapper for compatibility: allow direct import of functions from the module
async def get_user_by_email_or_username(session: AsyncSession, identifier: str):
    """Get a user by email or username using AuthService internally"""
    return await AuthService(session).get_user_by_email_or_username(identifier)
