from fastapi import APIRouter, Depends, HTTPException, Body, Request
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_session
from app.schemas.user import UserCreate, UserLogin, UserOut, TokenResponse, TokenRefreshResponse
from app.services.auth import AuthService
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

router = APIRouter()

limiter = Limiter(key_func=get_remote_address)

@router.post(
    "/register",
    response_model=UserOut,
    summary="Register a new user",
    description="Registers a new user with email, username, and password. Returns the created user. Rate limited to 5 requests per minute."
)
@limiter.limit("5/minute")
async def register(user: UserCreate, request: Request, db: AsyncSession = Depends(get_session)):
    existing = await AuthService(db).get_user_by_email_or_username(user.email)
    if existing:
        raise HTTPException(status_code=400, detail="User already exists")
    new_user = await AuthService(db).create_user(user.email, user.username, user.password)
    return new_user

@router.post(
    "/login",
    response_model=TokenResponse,
    summary="User login",
    description="Authenticates a user with email/username and password. Returns access and refresh tokens. Rate limited to 5 requests per minute."
)
@limiter.limit("5/minute")
async def login(login_data: UserLogin, request: Request, db: AsyncSession = Depends(get_session)):
    user = await AuthService(db).authenticate_user(login_data.login, login_data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    tokens = AuthService(db).generate_tokens(user)
    return tokens

@router.post(
    "/google-login",
    response_model=TokenResponse,
    summary="Login with Google",
    description="Authenticates a user via Google OAuth. If the user does not exist, creates a new account. Returns access and refresh tokens. Rate limited to 5 requests per minute."
)
@limiter.limit("5/minute")
async def google_login(request: Request, google_token: str = Body(...), db: AsyncSession = Depends(get_session)):
    email = google_token  # У реальності парсити через Google API
    user = await AuthService(db).get_user_by_email_or_username(email)
    if not user:
        user = await AuthService(db).create_user(email=email, username=None, password=None, is_google=True)
    tokens = AuthService(db).generate_tokens(user)
    return tokens

@router.post(
    "/refresh",
    response_model=TokenRefreshResponse,
    summary="Refresh access token",
    description="Refreshes the access token using a valid refresh token. Returns a new access token. Rate limited to 5 requests per minute."
)
@limiter.limit("5/minute")
async def refresh_token(request: Request, refresh_token: str = Body(..., embed=True), db: AsyncSession = Depends(get_session)):
    new_access = AuthService(db).refresh_access_token(refresh_token)
    if not new_access:
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    return {"access_token": new_access, "token_type": "bearer"}
