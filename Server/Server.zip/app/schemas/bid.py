from pydantic import BaseModel, Field
from datetime import datetime

class BidCreate(BaseModel):
    auction_id: int = Field(..., example=1)
    amount: int = Field(..., example=600)

class BidOut(BaseModel):
    id: int = Field(..., example=1)
    auction_id: int = Field(..., example=1)
    bidder_id: int = Field(..., example=3)
    amount: int = Field(..., example=600)
    created_at: datetime = Field(..., example="2024-06-01T13:00:00Z")

    class Config:
        from_attributes = True

class CreateBid(BaseModel):
    # add fields as needed
    pass

class OutBid(BaseModel):
    id: int = Field(..., example=1)
    # add other fields as needed

    class Config:
        from_attributes = True