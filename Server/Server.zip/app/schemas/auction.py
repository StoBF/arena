from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional

class AuctionCreate(BaseModel):
    item_id: int = Field(..., example=101)
    start_price: int = Field(..., example=500)
    duration: int = Field(..., example=24, description="у годинах")
    quantity: int = Field(1, example=1)

class AuctionOut(BaseModel):
    id: int = Field(..., example=1)
    item_id: int = Field(..., example=101)
    seller_id: int = Field(..., example=5)
    start_price: int = Field(..., example=500)
    current_price: int = Field(..., example=750)
    end_time: datetime = Field(..., example="2024-06-01T12:00:00Z")
    status: str = Field(..., example="active")
    winner_id: Optional[int] = Field(None, example=None)
    quantity: int = Field(..., example=1)
    created_at: datetime = Field(..., example="2024-05-31T12:00:00Z")

    class Config:
        from_attributes = True

class AuctionListOut(AuctionOut):
    pass

class AuctionLotCreate(BaseModel):
    hero_id: int = Field(..., example=10)
    starting_price: int = Field(..., example=1000)
    buyout_price: Optional[int] = Field(None, example=2000)
    duration: int = Field(..., example=24)

class AuctionLotOut(BaseModel):
    id: int = Field(..., example=1)
    hero_id: int = Field(..., example=10)
    seller_id: int = Field(..., example=5)
    starting_price: int = Field(..., example=1000)
    current_price: int = Field(..., example=1200)
    buyout_price: Optional[int] = Field(None, example=2000)
    end_time: datetime = Field(...)
    winner_id: Optional[int] = Field(None, example=None)
    is_active: bool = Field(..., example=True)
    created_at: datetime = Field(...)

    class Config:
        from_attributes = True

class CreateAuctionLot(BaseModel):
    # add fields as needed
    pass

class OutAuctionLot(BaseModel):
    id: int = Field(..., example=1)
    # add other fields as needed

    class Config:
        from_attributes = True

class BidCreate(BaseModel):
    auction_id: int = Field(..., example=1)
    amount: int = Field(..., example=1000)

class BidOut(BaseModel):
    id: int = Field(..., example=1)
    auction_id: int = Field(..., example=1)
    bidder_id: int = Field(..., example=2)
    amount: int = Field(..., example=1000)
    created_at: datetime = Field(...)

    class Config:
        from_attributes = True

class AutoBidCreate(BaseModel):
    auction_id: Optional[int] = Field(None, example=1)
    lot_id: Optional[int] = Field(None, example=1)
    max_amount: int = Field(..., example=5000)

class AutoBidOut(BaseModel):
    id: int = Field(..., example=1)
    auction_id: Optional[int] = Field(None, example=1)
    lot_id: Optional[int] = Field(None, example=1)
    user_id: int = Field(..., example=2)
    max_amount: int = Field(..., example=5000)
    created_at: datetime = Field(...)

    class Config:
        from_attributes = True