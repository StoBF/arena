import asyncio
import logging
from datetime import datetime
from sqlalchemy.future import select
from app.database.models.models import Auction
from app.database.session import AsyncSessionLocal
from app.services.auction import AuctionService
from app.core.redis_pubsub import publish_message

async def close_expired_auctions_task():
    while True:
        await asyncio.sleep(60)  # раз на хвилину
        async with AsyncSessionLocal() as session:
            async with session.begin():
                now = datetime.utcnow()
                result = await session.execute(
                    select(Auction).where(Auction.status == "active", Auction.end_time <= now)
                )
                expired_auctions = result.scalars().all()
                if expired_auctions:
                    logging.info(f"[AUCTION] Закриваю {len(expired_auctions)} протермінованих аукціонів.")
                for auction in expired_auctions:
                    logging.info(f"[AUCTION] Закриття аукціону id={auction.id}, item_id={auction.item_id}")
                    auction_service = AuctionService(session)
                    await auction_service.close_auction(auction.id)
                    # Повідомлення учасникам через Redis Pub/Sub
                    if auction.winner_id:
                        msg_win = f"Ви виграли лот #{auction.id}, ставка: {auction.current_price}!"
                        msg_sell = f"Ваш лот #{auction.id} продано. Переможець: герой {auction.winner_id}, ціна: {auction.current_price}."
                        # Публікуємо повідомлення в приватні канали користувачів
                        await publish_message("private", {"type": "system", "text": msg_win}, auction.winner_id)
                        await publish_message("private", {"type": "system", "text": msg_sell}, auction.seller_id)
                        logging.info(f"[AUCTION] Повідомлено переможця id={auction.winner_id} та продавця id={auction.seller_id}")
                    else:
                        msg = f"Ваш лот #{auction.id} завершився без ставок."
                        # Публікуємо повідомлення в приватний канал продавця
                        await publish_message("private", {"type": "system", "text": msg}, auction.seller_id)
                        logging.info(f"[AUCTION] Повідомлено продавця id={auction.seller_id} про завершення без ставок.")
                if not expired_auctions:
                    logging.info("[AUCTION] Немає аукціонів для закриття.") 